package proven.teamplayer.servlets;
 
//import proven.friends.lib.FriendForm;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
import java.util.List;
import javax.servlet.RequestDispatcher;
import cat.proven.teamplayer.model.Model;
import cat.proven.teamplayer.model.Team;
import proven.teamplayer.lib.TeamForm;
 
/**
 * Servlet to resolve requests in Friends application
 *
 * @author ProvenSoft
 */
public class TeamServletJson extends HttpServlet {
 
    private Model model;
 
 
    @Override
    public void init() throws ServletException {
        this.model = new Model();
    }
 
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the resultCode.">
    /**
     * Handles the HTTP GET method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processGetRequest(request, response);
    }
 
    /**
     * Handles the HTTP POST method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processPostRequest(request, response);
    }
 
    /**
     * Handles the HTTP PUT method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
    }
 
    /**
     * Handles the HTTP DELETE method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
    }
    /**
     * ProcessRequest
     * executes actions sended by get to manage categories.
     *
     * @param request
     * @param response
     */
    
    public void processGetRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action != null) {
            switch (action) {
                case "list_all": //list all friends
                    listAllTeams(request, response);
                    break;
                case "search_by_id": //list friend by phone
                    searchById(request, response);
                    break;
                case "search_by_name": //list friend by phone
                    searchByName(request, response);
                    break;
                default: //unknown option.
                    redirectError(request, response, "bad_parameter");
                    break;
            }
        } else { // parameter action needed
            redirectError(request, response, "no_action");
        }
    }
 
    /**
     * ProcessRequest
     * executes actions sended by post to manage categories.
     *
     * @param request
     * @param response
     */
    public void processPostRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action != null) {
            switch (action) {
                case "add": //add
                    addNewTeam(request, response);
                    break;
                case "modify": //modify
                    modifyTeam(request, response);
                    break;
                case "remove": //delete
                    removeTeam(request, response);
                    break;
                default: //unknown option.
                    redirectError(request, response, "bad_parameter");
                    break;
            }
        } else { // parameter action needed
            redirectError(request, response, "no_action");
        }
    }
 
    /**
     * serves a formated list of all friends
     *
     * @param request
     * @param response
     *
     */
    public void listAllTeams(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Team> entityList = (List<Team>) model.findAllTeams();
        TeamPlayerRequestResult result = new TeamPlayerRequestResult(entityList, 1);
        request.setAttribute("result", result);
        RequestDispatcher rd = getServletContext().getRequestDispatcher("/WEB-INF/jsp/json-result.jsp");
        rd.forward(request, response);
    }
 
    /**
     * Adds new team to data source of Model
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void addNewTeam(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int resultCode = -1;
        Team team = TeamForm.getData(request);
        if (team != null) {
            resultCode = model.insert(team);
        } else {
            resultCode = -1;
        }
        TeamPlayerRequestResult result = new TeamPlayerRequestResult(team, resultCode);
        request.setAttribute("result", result);
        RequestDispatcher rd = getServletContext().getRequestDispatcher("/WEB-INF/jsp/json-result.jsp");
        rd.forward(request, response);
 
    }
 
 
 
    /**
     * Search a team by id in data source of Model
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void searchById(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("id");
        TeamPlayerRequestResult result;
        if (id != null) {
           try{
            int idInt = Integer.parseInt(id);
            Team team = new Team(idInt);
            Team found = model.find(team);
            if (found != null) {
                result = new TeamPlayerRequestResult(found, 1);
            } else {
                result = new TeamPlayerRequestResult(null, -2);
            }
           }catch(NumberFormatException ex){
               result = new TeamPlayerRequestResult(null, -1);
           }
        } else {
            result = new TeamPlayerRequestResult(null, -1);
        }
 
        request.setAttribute("result", result);
        RequestDispatcher rd = getServletContext().getRequestDispatcher("/WEB-INF/jsp/json-result.jsp");
        rd.forward(request, response);
    }
 
    /**
     * Search a List of teams by name in data source of Model
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void searchByName(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        TeamPlayerRequestResult result;
        if (name != null) {
            List<Team> resultList = model.findTeamsByName(name);
            if (resultList != null) {
                result = new TeamPlayerRequestResult(resultList, 1);
            } else {
                result = new TeamPlayerRequestResult(null, -2);
            }
        } else {
            result = new TeamPlayerRequestResult(null, -1);
        }
 
        request.setAttribute("result", result);
        RequestDispatcher rd = getServletContext().getRequestDispatcher("/WEB-INF/jsp/json-result.jsp");
        rd.forward(request, response);
    }
 
    /**
     * Modify team to data source of Model
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void modifyTeam(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Team team = TeamForm.getData(request);
        int resultCode = -1;
 
        if (team != null) {
            resultCode = model.update(team);
        } else {
            resultCode = -1;
        }
        TeamPlayerRequestResult result = new TeamPlayerRequestResult(team, resultCode);
        request.setAttribute("result", result);
        RequestDispatcher rd = getServletContext().getRequestDispatcher("/WEB-INF/jsp/json-result.jsp");
        rd.forward(request, response);
 
    }
 
    /**
     * Remove a team from data source of Model
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void removeTeam(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("id");
        Team team = null;
        int resultCode = -1;
        if (id != null) {
            try{
                int idInt = Integer.parseInt(id);
                team = new Team(idInt);
                resultCode = model.delete(team);
            } catch(NumberFormatException ex){}
 
        }
        TeamPlayerRequestResult result = new TeamPlayerRequestResult(team, resultCode);
        request.setAttribute("result", result);
        RequestDispatcher rd = getServletContext().getRequestDispatcher("/WEB-INF/jsp/json-result.jsp");
        rd.forward(request, response);
    }
 
 
    /**
     * serves Bad Request errors with HTTP Status 400
     *
     * @param request
     * @param response
     * @param error
     * @throws javax.servlet.ServletException
     * @throws java.io.IOException
     */
   public void redirectError(HttpServletRequest request, HttpServletResponse response, String error)
            throws ServletException, IOException {
        String errorMsg = null;
        switch (error) {
            case "bad_parameter": // bad parameter action
                errorMsg = "Bad Parameter action";
                break;
            default: // need parameter action
                errorMsg = "Parameter action needed";
        }
        response.sendError(HttpServletResponse.SC_BAD_REQUEST, errorMsg);
    }
}