/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proven.teamplayer.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import cat.proven.teamplayer.model.Model;
import cat.proven.teamplayer.model.Player;
import cat.proven.teamplayer.model.Team;

/**
 *
 * @author alumne
 */
//@WebServlet(name = "FriendServlet", urlPatterns = {"/FriendServlet"})
public class TeamPlayerServlet extends HttpServlet {
 
    private Model model;
 
    @Override
    public void init() throws ServletException {
        this.model = new Model();
    }
 
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP (code)GET(/code) method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
 
    /**
     * Handles the HTTP (code)POST(/code) method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
 
 
    /**
     * <strong>processRequest()</strong>
     * executes actions to manage categories.
     * @param request
     * @param response
     */
    public void processRequest(HttpServletRequest request, HttpServletResponse response) 
        throws ServletException, IOException {
 
        listAllTeamsTxt(request, response);
    }
 
    /**
     * serves a list of all friends in text format 
     *
     * @param request
     * @param response
     */
    public void listAllTeamsTxt(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Team> entityList = (List<Team>) model.findAllTeams();
        try (PrintWriter out = response.getWriter()) {
 
            for (Team elem : entityList) {
                System.out.println(elem.toString());
                out.print(elem.toString());
            }
        }
    }
 
}
