package proven.teamplayer.lib;
 
import javax.servlet.http.HttpServletRequest;
import cat.proven.teamplayer.model.Player;
 
public class PlayerForm {
 
    /**
     * gets and validates data sent by client.
     * @param request http request object to get data from
     * @return friend object with data sent from client or null in case of error.
     */
    public static Player getData(HttpServletRequest request) {
        Player player = null;
        try {
            String id = request.getParameter("id");
            String name = request.getParameter("name");
            String yearBirth = request.getParameter("yearBirth");
            String teamid = request.getParameter("teamid");
            if ((id == null) || (name == null) || (yearBirth==null) || (teamid==null)) {
                player = null;
            } else {
                int idInt = Integer.parseInt(id);
                int yearBirthInt = Integer.parseInt(yearBirth);
                int teamidInt = Integer.parseInt(teamid);
                player = new Player(idInt,name,yearBirthInt,teamidInt);                
            }            
        } catch (NumberFormatException e) {
            player = null;
        }
        return player;
    }
 
}