package cat.proven.teamplayer;

public class teamPlayersApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
        }
    
}
