package cat.proven.teamplayer.model;

import cat.proven.teamplayer.model.persist.PlayerDaoArray;
import cat.proven.teamplayer.model.persist.PlayerDaoInterface;
import cat.proven.teamplayer.model.persist.TeamDaoArray;
import cat.proven.teamplayer.model.persist.TeamDaoInterface;
import java.util.List;

/**
 *
 * @author alumne
 */
public class Model {
    private final TeamDaoInterface teamDao;
    private final PlayerDaoInterface playerDao;

    public Model() {
        teamDao = new TeamDaoArray();
        playerDao = new PlayerDaoArray();
    }
    
    public Team find(Team team){
        return teamDao.find(team);
    }
    
    public Player find(Player player){
        return playerDao.find(player);
    }
    
    public List<Team> findAllTeams(){
       return teamDao.findAll();
    }
    
    public List<Player> findAllPlayers(){
       return playerDao.findAll();
    }
    
    public List<Team> findTeamsByName(String name){
        return teamDao.findByName(name);
    }
    
    public List<Player> findPlayersByName(String name){
        return playerDao.findByName(name);
    }
    
    public int insert(Team team){
        return teamDao.insert(team);
    }
    
    public int insert(Player player){
        return playerDao.insert(player);
    }
    
    public int update(Team team){
        return teamDao.update(team);
    }
    
    public int update(Player player){
        return playerDao.update(player);
    }
    
    public int delete(Team team){
        return teamDao.delete(team);
    }
    
    public int delete(Player player){
        return playerDao.delete(player);
    }
    
    public List<Player> searchTeamPlayers(Team t){
        return teamDao.searchTeamPlayers(t);
    }
    
    public Team searchPlayerTeam(Player p){
        return playerDao.searchPlayerTeam(p);
    }
    
    public List<Player> searchPlayerByTeamid(int teamid){
        return playerDao.searchPlayerByTeamid(teamid);
    }
}
