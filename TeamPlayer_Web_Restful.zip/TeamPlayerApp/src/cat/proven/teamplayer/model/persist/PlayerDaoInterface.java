/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.proven.teamplayer.model.persist;

import cat.proven.teamplayer.model.Player;
import cat.proven.teamplayer.model.Team;
import java.util.List;

/**
 *
 * @author alumne
 */
public interface PlayerDaoInterface {
    
    /**
     * find a player
     * @param player to be found
     * @return player found
     */
    Player find(Player player);
    
    /**
     * find all the players
     * @return a list with players found
     */
    List<Player> findAll();
    
    /**
     * searches a player with the name
     * @param name of the player to find
     * @return list of player with that name
     */
    List<Player> findByName(String name);
    
    /**
     * Add a new player
     * @param player to add
     * @return the number of rows affected
     */
    int insert(Player player);
    
    /**
     * modifies oldActor to newActor
     * @param oldPlayer player to be modified
     * @param newPlayer player wih new values
     * @return the number of rows affected
     */
    int update(Player player);
    
    /**
     * delete a player
     * @param player to be deleted
     * @return the number of rows affected
     */
    int delete(Player player);
 
    
    /**
     * Search the team of qa player
     * @param player of the team to search
     * @return team of the player
     */
    Team searchPlayerTeam(Player player);
    
    List<Player> searchPlayerByTeamid(int teamid);
}
