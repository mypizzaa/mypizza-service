/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.proven.teamplayer.model.persist;

import cat.proven.teamplayer.model.Player;
import cat.proven.teamplayer.model.Team;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author alumne
 */
public class PlayerDaoArray implements PlayerDaoInterface {
    
    private final List<Player> dataSource;

    public PlayerDaoArray() {
        dataSource = new ArrayList();
        loadData();
    }
    
    @Override
    public Player find(Player player){
        Player playerFound;
        int index = dataSource.indexOf(player);
        if (index >= 0) {
            playerFound = dataSource.get(index);
        }
        else {
            playerFound = null;
        }
        return playerFound;
    }
    
    @Override
    public List<Player> findAll(){
        return dataSource;
    }
    
    @Override
    public List<Player> findByName(String name){
        List<Player> playerList = new ArrayList();
        for(Player p: dataSource){
            if(p.getName().equals(name)){
                playerList.add(p);
            }
        }        
        return playerList;
    }
    
    @Override
    public int insert(Player player){
        int rowsAffected;
        boolean alreadyExists = dataSource.contains(player);
        if (alreadyExists) {
            rowsAffected = 0;
        }
        else {
            if (dataSource.add(player)) rowsAffected = 1;
            else rowsAffected = 0;
        }
        return rowsAffected;  
    }
     
    @Override
    public int update(Player player){
        int rowsAffected;
        int index = dataSource.indexOf(player);
        if (index >= 0) {
            dataSource.set(index, player);
            rowsAffected = 1;
        }
        else {
            rowsAffected = 0;
        }
        return rowsAffected;  
    }
    
    public int delete(Player player){
        int rowsAffected;
        if (dataSource.contains(player)) {
            dataSource.remove(player);
            rowsAffected = 1;
        }
        else {
            rowsAffected = 0;
        }
        return rowsAffected;
    }
    
    public void loadData(){
        dataSource.add(new Player(1, "Miquel Gomez Villagrasa", 1997, 2));
        dataSource.add(new Player(2, "Raimon Gomez Villagrasa", 1997, 2));
        dataSource.add(new Player(3, "Lionel Messi", 1990, 1));
        dataSource.add(new Player(4, "Michael Anderson", 1985, 3));
        dataSource.add(new Player(5, "Zidane", 1980, 4));
        dataSource.add(new Player(6, "Zidane", 1982, 4));

                
    }

    @Override
    public Team searchPlayerTeam(Player player) {
        Team t = null;
        int index = dataSource.indexOf(player);
        if (index != -1){
            Player p = dataSource.get(index);
            TeamDaoArray tda = new TeamDaoArray();
            for(Team team: tda.findAll()){
                if(p.getTeamId() == team.getId()){
                    t = team;
                }
            }
        }
        
        return t;
    }

    @Override
    public  List<Player> searchPlayerByTeamid(int teamid) {
        List<Player> playerList = new ArrayList();
        for(Player p: dataSource){
            if(p.getTeamId()==teamid){
                playerList.add(p);
            }
        }        
        return playerList;
    }
}
