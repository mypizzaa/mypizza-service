/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.proven.teamplayer.model.persist;

import cat.proven.teamplayer.model.Player;
import cat.proven.teamplayer.model.Team;
import java.util.List;

/**
 *
 * @author alumne
 */
public interface TeamDaoInterface {
    
    /**
     * searches a tema
     * @param team to be searched
     * @return team searched
     */
    Team find(Team team);
    
    /**
     * search all the teams
     * @return a list of all teams
     */
    List<Team> findAll();
   
    /**
     * find a team by its name
     * @param name of the team to be find
     * @return a list if the teams with that name
     */
    List<Team> findByName(String name);
    
    /**
     * add a new team
     * @param team team to add
     * @return the number of rows affected
     */
    int insert(Team team);
    
    /**
     * modify oldFilm values to newFilm values
     * @param oldTeam team to be modified
     * @param newTeam team with new values
     * @return the number of rows affected
     */
    int update(Team team);
    
    /**
     * remove a team
     * @param team team to be removed
     * @return the number of rows affected
     */
    int delete(Team team);
    
    /**
     * Search the players of a team
     * @param team of the players
     * @return list of players in the team
     */
    List<Player> searchTeamPlayers(Team team);
}
