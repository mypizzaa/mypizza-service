/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.proven.teamplayer.model.persist;

import cat.proven.teamplayer.model.Player;
import cat.proven.teamplayer.model.Team;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author alumne
 */
public class TeamDaoArray implements TeamDaoInterface{
    private final List<Team> dataSource;

    public TeamDaoArray() {
        dataSource = new ArrayList();
        loadData();
    }
    
    @Override
    public Team find(Team team){
        Team teamFound;
        int index = dataSource.indexOf(team);
        if (index >= 0) {
            teamFound = dataSource.get(index);
        }
        else {
            teamFound = null;
        }
        return teamFound;
    }
    
    @Override
    public List<Team> findAll(){
        return dataSource;
    }
    
    @Override
    public List<Team> findByName(String name){
        List<Team> teamList = new ArrayList();
        for(Team t: dataSource){
            if(t.getName().equals(name)){
                teamList.add(t);
            }
        }        
        return teamList;
    }
    
    @Override
    public int insert(Team team){
        int rowsAffected;
        boolean alreadyExists = dataSource.contains(team);
        if (alreadyExists) {
            rowsAffected = 0;
        }
        else {
            if (dataSource.add(team)) rowsAffected = 1;
            else rowsAffected = 0;
        }
        return rowsAffected;  
    }
     
    @Override
    public int update(Team team){
        int rowsAffected;
        int index = dataSource.indexOf(team);
        if (index >= 0) {
            dataSource.set(index, team);
            rowsAffected = 1;
        }
        else {
            rowsAffected = 0;
        }
        return rowsAffected;  
    }
    
    @Override
    public int delete(Team team){
        int rowsAffected;
        if (dataSource.contains(team)) {
            dataSource.remove(team);
            rowsAffected = 1;
        }
        else {
            rowsAffected = 0;
        }
        return rowsAffected;
    }
    
    @Override
    public List<Player> searchTeamPlayers(Team team){
        
        List<Player> listPlayer = new ArrayList();
         
        PlayerDaoArray pda = new PlayerDaoArray();
        
        for(Player p: pda.findAll()){
            if (p.getTeamId() == team.getId()){
                listPlayer.add(p);
            }
        }
        
        
        return listPlayer;
    }
    
   public void loadData(){
       dataSource.add(new Team(1, "FC Barcelona", "1st division BBVA league"));
       dataSource.add(new Team(2, "FC Can Buxeres", "Amateur 3rd division Catalonia league"));
       dataSource.add(new Team(3, "RCD Español", "1st division BBVA league"));
       dataSource.add(new Team(4, "FC Can Buxeres", "Juvenil 1st division Catalonia league"));
   }
}
