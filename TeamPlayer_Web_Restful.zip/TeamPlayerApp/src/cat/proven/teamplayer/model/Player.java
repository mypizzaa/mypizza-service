/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.proven.teamplayer.model;

import java.util.Objects;

/**
 *
 * @author alumne
 */
public class Player {
    
    private long id;
    private String name;
    private int yearBirth;
    private long teamId;

//    public Player(long id, String name, String yearBirth) {
//        this.id = id;
//        this.name = name;
//        this.yearBirth = yearBirth;
//    }

    public Player(long id, String name, int yearBirth, long teamId) {
        this.id = id;
        this.name = name;
        this.yearBirth = yearBirth;
        this.teamId = teamId;
    }
    
    public Player() {
    }

    public Player(long id) {
        this.id = id;
    }
    
    public Player(Player a){
        this.id = a.id;
        this.name = a.name;
        this.yearBirth = a.yearBirth;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getYearBirth() {
        return yearBirth;
    }
    
    public void setId(long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setYearBirth(int yearBirth) {
        this.yearBirth = yearBirth;
    }

    public long getTeamId() {
        return teamId;
    }

    public void setTeamId(long teamId) {
        this.teamId = teamId;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + (int) (this.id ^ (this.id >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Player other = (Player) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Player{");
        sb.append("id=");sb.append(id);
        sb.append("; name="); sb.append(name);
        sb.append("; yearBirth="); sb.append(yearBirth);
        sb.append("}");
        
        return sb.toString();
    }
   
}
