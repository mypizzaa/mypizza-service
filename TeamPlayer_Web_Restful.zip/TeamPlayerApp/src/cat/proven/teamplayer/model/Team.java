/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.proven.teamplayer.model;

import java.util.Objects;

/**
 *
 * @author alumne
 */
public class Team {
    
    private long id;
    private String name;
    private String description;

    public Team(long id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }

    public Team() {
    }

    public Team(long id) {
        this.id = id;
    } 
    
    public Team(Team f){
        this.id = f.id;
        this.name = f.name;
        this.description = f.description;
    }

    public long getId() {
        return id;
    }
    

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 89 * hash + (int) (this.id ^ (this.id >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Team other = (Team) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Team{");
        sb.append("id=");sb.append(id);
        sb.append("; name="); sb.append(name);
        sb.append("; description="); sb.append(description);
        sb.append("}");
        
        return sb.toString();
    }

}
