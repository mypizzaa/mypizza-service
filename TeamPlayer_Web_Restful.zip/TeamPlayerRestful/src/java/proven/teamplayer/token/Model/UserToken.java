/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proven.teamplayer.token.Model;

import proven.users.model.User;

/**
 *
 * @author alumne
 */
public class UserToken {
    
    private User u;
    private String token;

    public UserToken(User u, String token) {
        this.u = u;
        this.token = token;
    }

    public UserToken() {
    }

    public User getUser() {
        return u;
    }

    public String getToken() {
        return token;
    }

    public void setUsername(User u) {
        this.u = u;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public String toString() {
        return "UserToken{" + "username=" + u.toString() + ", token=" + token + '}';
    }        
    
}
