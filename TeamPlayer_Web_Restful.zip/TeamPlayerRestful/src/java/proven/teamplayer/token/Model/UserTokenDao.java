/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proven.teamplayer.token.Model;

import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author alumne
 */
public class UserTokenDao {
    
    private static UserTokenDao instance;    
    private List<UserToken> data;
    
    public  UserTokenDao()  {
        data = new ArrayList<>(); 
    }   

    public static UserTokenDao getInstance(){
      if (instance == null) {
           instance = new UserTokenDao();
      }
      return instance;
    }
    
    public int insert(UserToken entity) {
        int rowsAffected;
        boolean alreadyExists = data.contains(entity);
        if (alreadyExists) {
            rowsAffected = 0;
        }
        else {
            boolean success = data.add(entity);
            if (success) rowsAffected = 1;
            else rowsAffected = 0;
        }
        return rowsAffected;    
    }

    public List<UserToken> getData() {
        return data;
    }
    
    
}
