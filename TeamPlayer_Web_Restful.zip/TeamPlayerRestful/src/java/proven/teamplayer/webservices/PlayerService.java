package proven.teamplayer.webservices;
 
import cat.proven.teamplayer.model.Model;
import cat.proven.teamplayer.model.Player;
import cat.proven.teamplayer.model.Team;
import com.google.gson.Gson;
import java.util.List;
import java.util.Locale;
 
import javax.servlet.ServletContext;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
 
import proven.msg.Message;
import proven.msg.PropertiesLanguage;
 
/**
 * Service of friend application
 * @author ProvenSoft
 */
@Path("/player")
public class PlayerService {
   /**
    * data model to provide data access.
    */
   private final Model model;
 
   /**
    * Constructor. It gets a reference to the model
    * and saves it in the application context to 
    * @param context the application context
    */
   public PlayerService(@Context ServletContext context){        
        if(context.getAttribute("model") != null) {
            model = (Model) context.getAttribute("model");
        } else {
            model = new Model();
            context.setAttribute("model", model);
        }
   }
 
   /**
    * gets all friends
    * @return list of friends in json
    */
   @GET
   @Path("/all")
   @Produces(MediaType.APPLICATION_JSON)
   public String searchAll(){
      return new Gson().toJson(model.findAllPlayers());
   }
   
    /**
    * Find friend by phone
    * @param phone to search for
    * @return  friend or code 0 Friend Not Found
   */
   @GET
   @Path("/{id}")
   @Produces(MediaType.APPLICATION_JSON)   
   public String searchById(@PathParam("id") int id){
        Player p = model.find(new Player(id));
        if(p == null) 
            return new Gson().toJson(new Message(0,
                PropertiesLanguage.returnValue(Locale.ENGLISH,"notfound")));
        else
            return new Gson().toJson(p);
    }
 
    /**
    * Find friend by name
    * @param name to search for
    * @return  friend or code 0 Friend Not Found
   */
   @GET
   @Path("/name/{name}")
   @Produces(MediaType.APPLICATION_JSON)
   public String searchFriendByName(@PathParam("name") String name){
        List<Player> resultList = model.findPlayersByName(name);
        if(resultList == null) 
            return new Gson().toJson(new Message(0,
                PropertiesLanguage.returnValue(Locale.ENGLISH,"notfound")));
        else
            return new Gson().toJson(resultList);
    }
   
   /**
    * find players by team id
    * @param id of the team
    * @return 
    */
   @GET
   @Path("/players/{id}")
   @Produces(MediaType.APPLICATION_JSON)
   public String findPlayersByTeam(@PathParam("id") int id){
        List<Player> resultList = model.searchPlayerByTeamid(id);
        if(resultList == null) 
            return new Gson().toJson(new Message(0,
                PropertiesLanguage.returnValue(Locale.ENGLISH,"notfound")));
        else
            return new Gson().toJson(resultList);
    }
 
 
   /**
    * Add a new friend
    * @param phone
    * @param name
    * @param age
    * @return  1 ok , 0 fail
   */
   @POST
   @Path("/add")
   @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
   @Produces(MediaType.APPLICATION_JSON)
   public String add(@FormParam("id") int id,
                     @FormParam("name") String name,
                     @FormParam("yearbirth") int yearbirth,
                     @FormParam("idteam") int idteam){
      Player p = new Player(id,name,yearbirth, idteam);
      if(model.insert(p) == 1) {
          return new Gson().toJson(new Message(1,
            PropertiesLanguage.returnValue(Locale.ENGLISH,"ok")));
      }else{
         return new Gson().toJson(new Message(0,
            PropertiesLanguage.returnValue(Locale.ENGLISH,"fail")));
      }
   }
 
   /**
    * Modify a friend
    * @param oldPhone
    * @param phone
    * @param name
    * @param age
    * @return  1 ok , 0 fail
   */
   @POST
   @Path("/{id}/update")
   @Consumes(MediaType.APPLICATION_FORM_URLENCODED)   
   @Produces(MediaType.APPLICATION_JSON)
   public String modify(@PathParam("id") int id,
                        @FormParam("name") String name,
                        @FormParam("yearbirth") int yearbirth,
                        @FormParam("idteam") int idteam){
      if(model.update( 
            new Player(id,name,yearbirth,idteam)
        ) == 1) {
          return new Gson().toJson(new Message(1,
            PropertiesLanguage.returnValue(Locale.ENGLISH,"ok")));
      }else{
         return new Gson().toJson(new Message(0,
            PropertiesLanguage.returnValue(Locale.ENGLISH,"fail")));
      } 
   }
 
   /**
    * Remove a friend
    * @param phone of friend to remove
    * @return  1 ok , 0 fail
    * 
   */
   @POST
   @Path("/{id}/delete")
   @Produces(MediaType.APPLICATION_JSON)
   public String remove(@PathParam("id") int id){
      if(model.delete(new Team(id)) == 1) {
          return new Gson().toJson(new Message(1,
           PropertiesLanguage.returnValue(Locale.ENGLISH,"ok")));
      }else{
         return new Gson().toJson(new Message(0,
            PropertiesLanguage.returnValue(Locale.ENGLISH,"fail")));
      }
   }
}
