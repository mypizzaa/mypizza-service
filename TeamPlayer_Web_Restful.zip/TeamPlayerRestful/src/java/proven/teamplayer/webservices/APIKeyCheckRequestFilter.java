package proven.teamplayer.webservices;

import com.google.gson.Gson;
import java.io.IOException;
import java.net.URI;
import java.util.List;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;
 
import proven.msg.Message;
import proven.teamplayer.token.Model.UserToken;
import proven.teamplayer.token.Model.UserTokenDao;
import proven.users.model.User;
 
/**
 * Filter that secure Service with API KEY
 * ContainerResponseFilter are server-side filters.
 * The filter is a provider class and thus must be marked with @Provider. 
 * This ensures that the filters are automatically discovered. 
 * If the filter is not marked with @Provider, it
 * needs to be explicitly registered in the Application class.
 * Filter is applied globally on all resources with the incoming HTTP request.
 * @author ProvenSoft
 */
 
//@Provider
public class APIKeyCheckRequestFilter implements ContainerRequestFilter {
 
    private static final String API_KEY = "X-API-KEY";

    private UserTokenDao utd;
    
 
    @Override
    public void filter(ContainerRequestContext containerRequestContext) 
            throws IOException {
        utd = new UserTokenDao();
        final String apiKey = containerRequestContext.getHeaders().getFirst(API_KEY);
        System.out.println(apiKey);
        URI myURI = containerRequestContext.getUriInfo().getAbsolutePath();
        String myPath = myURI.getPath();
        // securing the services
        if (/*!isPublicService(myPath) && */!isValidApiKey(apiKey, myPath)) {
            containerRequestContext
                .abortWith(
                    Response
                        .status(Response.Status.UNAUTHORIZED)
                        .entity(new Gson().toJson(new Message(0, "API Key not valid")))
                        .build()
                );
        }
    }
 
    /**
     * Validates if service is Public to access without ApiKey
     * @param path : path of service
     * @return
     */
    /*public boolean isPublicService(String path) {
        boolean isPublic = false;
        // TODO : put public services
        if(path.endsWith("/all")) {
            isPublic = true;
        }
        return isPublic;
        //return true;  //change this to protect api with token.
    }*/
 
    /**
     * Validates if apiKey is valid
     * @param apiKey : api key of service
     * @return
     */
    public boolean isValidApiKey(String apiKey, String path) {
        boolean isValid = false;
        if (apiKey != null && !apiKey.isEmpty()) {
            List<UserToken> utdList = utd.getData();
            for(UserToken ut: utdList){
                if (ut.getToken().equals(apiKey)){
                   if (ut.getUser().getRole().equals("admin")){
                       isValid = true;
                   } else if (ut.getUser().getRole().equals("user") && 
                   (path.endsWith("/all") || path.endsWith("/{id}") || 
                    path.endsWith("/name/{name}") || path.endsWith("/players/{id}"))){
                       isValid = true;
                   }
                }
            }
        }
        return isValid;
    }
 
}