
package proven.teamplayer.webservices;

import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import proven.teamplayer.token.Model.UserToken;
import proven.teamplayer.token.Model.UserTokenDao;
import proven.users.model.User;
import proven.users.model.persist.UserArrayDao;


@Path("/token-service")
public class TokenService {
    
    private UserArrayDao uad;
    private UserTokenDao utd;
    private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    
    public TokenService(@Context ServletContext context){        
        if(context.getAttribute("uad") != null) {
            uad = (UserArrayDao) context.getAttribute("uad");
        } else {
            uad = new UserArrayDao();
            context.setAttribute("uad", uad);
        }
        
        if(context.getAttribute("utd") != null) {
            utd = (UserTokenDao) context.getAttribute("utd");
        } else {
            utd = new UserTokenDao();
            context.setAttribute("utd", utd);
        }
   }
    
    @POST
    @Path("/token")
    @Produces(MediaType.APPLICATION_JSON )
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response geToken(@FormParam("username") String username,
            @FormParam("password") String password) {
        // Authenticate the user using the credentials provided
        if (authenticate(username, password)) {
            // Issue a token for the user
            String token = issueToken();
            // Return the token on the response
            utd.insert(new UserToken(uad.find(new User(username, password)),token));
            
            return Response.ok(token).build();
        } else {
            return Response.status(Response.Status.FORBIDDEN).build();
        }
    }

    private boolean authenticate(String username, String password){
        User u = new User(username, password);
        return uad.validate(u);
    }

    private String issueToken() {
        return randomAlphaNumeric();
    }
    
    public String randomAlphaNumeric() {
        int count = 21;
        StringBuilder builder = new StringBuilder();
        while (count-- != 0) {
            int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
            builder.append(ALPHA_NUMERIC_STRING.charAt(character));
        }
        return builder.toString();
    }
}